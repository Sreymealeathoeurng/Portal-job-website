document.addEventListener("DOMContentLoaded", () => {
    const mainContent = document.getElementById("mainContent");
    const courseTableBody = document.getElementById("courseTable");

    // Toggle visibility function
    function toggleVisibility(containerId, isVisible) {
        const container = document.getElementById(containerId);
        container.style.display = isVisible ? "block" : "none";
        mainContent.style.display = isVisible ? "none" : "block";
    }

    // Load courses on page load
    loadCourses();

    // Load courses into the table
    function loadCourses() {
        const xhttp = new XMLHttpRequest();
        xhttp.open("GET", "https://example.com/api/courses", true); // Replace with your API endpoint
        xhttp.send();
        xhttp.onreadystatechange = function () {
            if (this.readyState === 4 && this.status === 200) {
                const courses = JSON.parse(this.responseText);
                let rows = '';
                courses.forEach((course, index) => {
                    rows += `
                        <tr>
                            <td>${index + 1}</td>
                            <td>${course.name}</td>
                            <td>${course.startDate}</td>
                            <td>${course.instructor}</td>
                            <td>${course.instructorEmail}</td>
                            <td>${course.totalStudents}</td>
                            <td>${course.status}</td>
                        </tr>`;
                });
                courseTableBody.innerHTML = rows;
            }
        };
    }

    // Register course functionality
    const registerButton = document.querySelector(".btn-register-course");
    if (registerButton) {
        registerButton.addEventListener("click", (event) => {
            event.preventDefault(); // Prevent form submission
            // Get input values
            const courseName = document.getElementById("course-name").value;
            const startDate = document.getElementById("start-date").value;
            const endDate = document.getElementById("end-date").value;
            const instructorName = document.getElementById("instructor-name").value;
            const instructorEmail = document.getElementById("instructor-email").value;
            const totalStudents = document.getElementById("total-students").value;
            const courseStatus = document.getElementById("course-status").value;

            // Validate inputs
            if (!courseName || !startDate || !endDate || !instructorName || 
                !instructorEmail || !totalStudents || !courseStatus) {
                alert("Please fill in all fields.");
                return;
            }

            // Create a new row and cells
            const newRow = document.createElement("tr");
            newRow.innerHTML = `
                <td>${courseTableBody.children.length + 1}</td>
                <td>${courseName}</td>
                <td>${startDate}</td>
                <td>${endDate}</td>
                <td>${instructorName}</td>
                <td>${instructorEmail}</td>
                <td>${totalStudents}</td>
                <td>${courseStatus}</td>
            `;

            // Append the new row to the table body
            courseTableBody.appendChild(newRow);

            // Clear the input fields
            document.getElementById("course-name").value = "";
            document.getElementById("start-date").value = "";
            document.getElementById("end-date").value = "";
            document.getElementById("instructor-name").value = "";
            document.getElementById("instructor-email").value = "";
            document.getElementById("total-students").value = "";
            document.getElementById("course-status").value = "";
        });
    }

    // Function to change content based on menu item clicked
    function loadContent(contentType) {
        const mainContent = document.getElementById('mainContent');

        mainContent.style.display = 'display';
    
        switch (contentType) {
            case 'course-manage':
                mainContent.innerHTML = '<h1>Course Management</h1><p>Manage your courses here.</p>';
                break;
            case 'manage-student':
                mainContent.innerHTML = '<h1>Manage Students</h1><p>Add or edit students.</p>';
                break;
            case 'marks-attendance':
                mainContent.innerHTML = '<h1>Marks Attendance</h1><p>Mark attendance here.</p>';
                break;
            case 'view-attendance':
                mainContent.innerHTML = '<h1>View Attendance</h1><p>View attendance records.</p>';
                break;
            case 'configure-camera':
                mainContent.innerHTML = '<h1>Configure Camera</h1><p>Set up your camera settings.</p>';
                break;
            default:
                mainContent.innerHTML = '<h1>Welcome! Please select an option from the menu.</h1>';
                break;
        }
    
        // Show the main content after updating
        mainContent.style.display = 'block';
    }
    

    // Add click event listener to each menu item
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(item => {
        item.addEventListener('click', (event) => {
            event.preventDefault(); // Prevent default anchor behavior
            const contentType = item.getAttribute('data-content');
            loadContent(contentType);
        });
    });
});