# myapp/models.py
from django.db import models

class StudentInformation(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone_number = models.CharField(max_length=15)
    student_class = models.CharField(max_length=50)

    def __str__(self):
        return self.name
